# -*- coding: utf-8 -*-

def data_egg():
    print("egg......")
    print("egg done!")